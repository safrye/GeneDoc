
    GeneDoc: Multiple Sequence Alignement Editor.
    Copyright (C) 2000 by Karl Nicholas

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA



1: This program was written under MSVC 1.52 (16 bit version) and MSVC 6.0 (32 bit version)

The 1.52 project and makefile are in the GeneDoc directories. The 32 bit project files are in the \Gene32 directory, but compile the source in the \GeneDoc directory.

extract files to \user\karl\*, thus making \users\karl\genedoc and \users\karl\gene32

Best bet, get MSVC 6.0 (or greater) and open Gene32\GeneDoc.dsw (workspace).



